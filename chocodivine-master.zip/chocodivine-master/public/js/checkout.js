document.querySelector(".paytmbtn").addEventListener("click",()=>{

 console.log(document.getElementById("paymentMode").value);
 document.getElementById("paymentMode").value="paytm";
});
